<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;


use Illuminate\Contracts\Auth\MustVerifyEmail;

class EmiCalculator extends Model
{
    
}
