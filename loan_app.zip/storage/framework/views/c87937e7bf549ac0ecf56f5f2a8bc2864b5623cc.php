<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

        <!-- Styles -->
        

        <style>
            body {
                font-family: 'Nunito';
            }
        </style>
    </head>
    <body class="antialiased">
        <!-- FORM STARTS HERE -->
        <div class="col-md-4">
            <div>
                <div class="page-header">
                    <h1><span class="glyphicon glyphicon-flash"></span> Calcukate EMI!</h1>
                </div>    

                <?php if(count($errors)  > 0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?><br>        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
            <form method="POST" action="/" novalidate>
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="name">Amount of loan</label>
                    <input required pattern="[0-9]+([,\.][0-9]+)?" type="text" id="amount" class="form-control" name="amount" placeholder="50000">
                </div> 
                
                <div class="form-group">
                    <label for="name">Intrest (%)</label>
                    <input required pattern="[0-9]+([,\.][0-9]+)?" type="text" id="interest" class="form-control" name="interest" placeholder="12.35">
                </div>
                
                <div class="form-group">
                    <label for="name">Duration (Months)</label>
                    <input required pattern="[0-9]+" type="text" id="duration" class="form-control" name="duration" placeholder="24">
                </div>
                
                <button type="submit" class="btn btn-success">Calculate!</button>
            </form>
        </div>
        <?php if(isset($data) && count($data)  > 0): ?>
            <div class="col-md-8">
                <center> <h1> Your EMI Calculation! </h1> </center>
                <table class="table table-hover table-striped">
                    <tr>
                        <th>SR NO</th>
                        <th>Interest</th>
                        <th>Beginning Balance</th>
                        <th>Principle</th>
                        <th>Total Payment</th>
                        <th>Ending Balance</th>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row['sn']); ?></td>
                            <td><?php echo e($row['interest']); ?></td>
                            <td><?php echo e($row['beginning_balance']); ?></td>
                            <td><?php echo e($row['principle']); ?></td>
                            <td><?php echo e($row['total_payment']); ?></td>
                            <td><?php echo e($row['ending_balance']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        <?php else: ?>
            <div><h1>Fill The form to calculate EMI!</h1></div>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\loan_app\resources\views/welcome.blade.php ENDPATH**/ ?>